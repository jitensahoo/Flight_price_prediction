# -*- coding: utf-8 -*-
import numpy as np
from flask import Flask,render_template,url_for,request
import pickle
app=Flask(__name__)
rfc=pickle.load(open('rfg.pkl','rb'))

@app.route('/')
def flight():
    return render_template('flight.html')

@app.route('/predict',methods=["POST"])
def predict():
    input_features=[int(x) for x in request.form.values()]
    final_features=[np.array(input_features)]
    pred=rfc.predict(final_features)
    
    output=round(pred[0],2)
    
    return render_template('flight.html',prediction_text='flight cost {}'.format(output))

if __name__ == "__main__":
    app.run(debug=True,use_reloader=False)

